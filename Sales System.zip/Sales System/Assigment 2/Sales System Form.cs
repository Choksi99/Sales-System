﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Assigment_1
{
    public partial class Form2 : Form
    {
        Form3 f3; Form4 f4; 
        // declaring variable for calculating
        double iGST,  iTotal , iNetPay, iSummary ;

        public Form2()
        {
          
            InitializeComponent();
        }

        //Declare Double Type
        double d_txtShoesQ;
        double d_txtGlovesQ;
        double d_txtJacketsQ;
        double d_txtBeaniesQ;
        double d_DiscountRate;

        // Declaring Value of Product 
        double d_txtShoesRate = 25;
        double d_txtGlovesRate = 15;
        double d_txtJacketsRate = 20;
        double d_txtBeaniesRate = 15;
        double Gst_Rate = 0.15;

        // Double for calculation
        double d_QuantityOfShoes;
        double d_QuantityOfGloves;
        double d_QuantityOfJackets;
        double d_QuantityOfBeanies;
        double d_Discount;
       
        //Declaring Variable
        private void GetDataFromUser()
        {
            double.TryParse(txtShoesQ.Text, out d_QuantityOfShoes);
            double.TryParse(txtJacketsQ.Text, out d_QuantityOfJackets);
            double.TryParse(txtGlovesQ.Text, out d_QuantityOfGloves);
            double.TryParse(txtBeaniesQ.Text, out d_QuantityOfBeanies);
            double.TryParse(txtDiscountRate.Text, out d_DiscountRate);
        }

       //Calculating Net pay for product & for other fees as well
        private void CalcNetPay()
        {
            GetDataFromUser();

            // Checking if it is selected :
            if (chkShoes.Checked) { d_txtShoesQ = d_QuantityOfShoes * d_txtShoesRate; }
            else { d_txtShoesQ = 0; }

            if (chkJackets.Checked) { d_txtJacketsQ = d_QuantityOfJackets * d_txtJacketsRate; }
            else { d_txtJacketsQ = 0; }

            if (chkGloves.Checked) { d_txtGlovesQ = d_QuantityOfGloves * d_txtGlovesRate; }
            else { d_txtGlovesQ = 0; }

            if (chkBeanies.Checked) { d_txtBeaniesQ = d_QuantityOfBeanies * d_txtBeaniesRate; }
            else { d_txtBeaniesQ = 0; }

            iNetPay = d_txtShoesQ + d_txtJacketsQ + d_txtGlovesQ + d_txtBeaniesQ;

            if (chkDiscount.Checked) { d_Discount = iNetPay * d_DiscountRate /100.0; }
            else { d_Discount = 0; }
          
            iSummary = iNetPay - d_Discount;

            // Displaying value of Discount Applied & Reset Value if Doesnt require 
            if (chkDiscount.Checked)
            {
                txtDiscountAmount.Text = d_Discount.ToString();
            }
            else
            {
                d_Discount = 0;
                txtDiscountRate.Text = "";
                txtDiscountAmount.Text = "";
            }

            // GST Calculation
            if (chkGSTRate.Checked)
            {
                iGST = iSummary * Gst_Rate;
                txtGSTAmount.Text = iGST.ToString();
            }
            else
            {
                iGST = 0;
                txtGSTAmount.Text = "";
            }

            iTotal = (iSummary + iGST );
            lblNetPay.Text = iTotal.ToString();
        }
   
        private void Form1_Load(object sender, EventArgs e)
        {
           
            // Declaring Value Of Product
            this.txtShoesRate.Text = d_txtShoesRate.ToString("C2");
            this.txtJacketsRate.Text = d_txtJacketsRate.ToString("C2");
            this.txtGlovesRate.Text = d_txtGlovesRate.ToString("C2");
            this.txtBeaniesRate.Text = d_txtBeaniesRate.ToString("C2");

            // When form load some of fields  Will off:
            txtCardNumber.Enabled = false;
            txtNameOnCard.Enabled = false;
            comboBoxCardType.Enabled = false;
            comboBoxExpiryMonth.Enabled = false;
            comboBoxExpiryYear.Enabled = false;
            txtShoesQ.Enabled = false;
            txtJacketsQ.Enabled = false;
            txtGlovesQ.Enabled = false;
            txtBeaniesQ.Enabled = false;
            txtGSTAmount.Enabled = false;

            // Loads all the Records from the file and displays to the List Box
            VM_LoadAllRecords();

            // Expiry Combo Box Year 
            int i_StartYear = 2018;
            for (int i_CurrentYear = i_StartYear; i_CurrentYear <= i_StartYear + 15; i_CurrentYear++)
            { 
            this.comboBoxExpiryYear.Items.Add(i_CurrentYear + " ");
            }
        }

        private void VM_LoadAllRecords()
        {
            lstAllRecords.Items.Clear();
            string[] as_entireData = System.IO.File.ReadAllLines("Records.txt");
            for (int i_index = 0; i_index < as_entireData.Length; i_index++)
            {
                lstAllRecords.Items.Add(as_entireData[i_index]);
            }
        }

        // Credit Card option Enable Code
        private void btnCreditCard_CheckedChanged(object sender, EventArgs e)
        {
            if(btnCreditCard.Checked == true) { pictureBox1.Visible = false; }
            else { pictureBox1.Visible = true; }
                txtCardNumber.Enabled = btnCreditCard.Checked;
                txtNameOnCard.Enabled = btnCreditCard.Checked;
                comboBoxCardType.Enabled = btnCreditCard.Checked;
                comboBoxExpiryMonth.Enabled = btnCreditCard.Checked;
                comboBoxExpiryYear.Enabled = btnCreditCard.Checked;   
        }

        // Summary Button 
        private void btnShowSummary_Click(object sender, EventArgs e)
        {
           
            // Getting Input From User (Help By IWan Tjhin)
            CalcNetPay();
        }

        // Matter for transfering Form data to a its original fields 
        private void LoadTheData()
        {
            string[] as_entireData = System.IO.File.ReadAllLines("Records.txt");


            int i_index = lstAllRecords.SelectedIndex;

            string[] as_singleRecord = as_entireData[i_index].Split(',');

            txtFirstName.Text = as_singleRecord[0];
            txtLastName.Text = as_singleRecord[1];
            txtStreetAddress.Text = as_singleRecord[2];
            txtCity.Text = as_singleRecord[3];
            ComboBoxCountry.Text = as_singleRecord[4];

            txtNameOnCard.Text = as_singleRecord[5];
            txtCardNumber.Text = as_singleRecord[6];
            comboBoxCardType.Text = as_singleRecord[7];
            comboBoxExpiryMonth.Text = as_singleRecord[8];
            comboBoxExpiryYear.Text = as_singleRecord[9];

            btnCash.Checked = Convert.ToBoolean(as_singleRecord[10]);
            btnCreditCard.Checked = Convert.ToBoolean(as_singleRecord[11]);
            btnBankTransfer.Checked = Convert.ToBoolean(as_singleRecord[12]);

            chkShoes.Checked = Convert.ToBoolean(as_singleRecord[13]);
            txtShoesQ.Text = as_singleRecord[14];

            chkJackets.Checked = Convert.ToBoolean(as_singleRecord[15]);
            txtJacketsQ.Text = as_singleRecord[16];

            chkGloves.Checked = Convert.ToBoolean(as_singleRecord[17]);
            txtGlovesQ.Text = as_singleRecord[18];

            chkBeanies.Checked = Convert.ToBoolean(as_singleRecord[19]);
            txtBeaniesQ.Text = as_singleRecord[20];
            chkDiscount.Checked = Convert.ToBoolean(as_singleRecord[21]);
            txtDiscountRate.Text = as_singleRecord[22];
            txtDiscountAmount.Text = as_singleRecord[23];
            chkGSTRate.Checked = Convert.ToBoolean(as_singleRecord[24]);
            txtGSTAmount.Text = as_singleRecord[25];
            lblNetPay.Text = as_singleRecord[26];

            VM_LoadAllRecords();
        }


        // Save the data to the file 
        private void btnSave_Click(object sender, EventArgs e)
        {

            DialogResult dialog = MessageBox.Show(" Are You Sure You Want to save the Data?" + "\n"+"\n"+
              " Kindly Check the Data Before Saving !!", "Information ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.No)
            {
                return;
            }

          
            String s_data;
            s_data = txtFirstName.Text + "," + txtLastName.Text + "," + txtStreetAddress.Text + "," +
                txtCity.Text + "," + ComboBoxCountry.Text + "," +

                txtNameOnCard.Text + "," + txtCardNumber.Text + "," + comboBoxCardType.Text + "," + comboBoxExpiryMonth.Text + "," +
                comboBoxExpiryYear.Text + "," +

                btnCash.Checked + "," + btnCreditCard.Checked + "," + btnBankTransfer.Checked + "," +

                chkShoes.Checked + "," + txtShoesQ.Text + "," + chkJackets.Checked + "," +
             txtJacketsQ.Text + "," + chkGloves.Checked + "," + txtGlovesQ.Text + "," +
             chkBeanies.Checked + "," + txtBeaniesQ.Text + "," +

             chkDiscount.Checked + "," + txtDiscountRate.Text + "," + txtDiscountAmount.Text + "," + chkGSTRate.Checked + "," + txtGSTAmount.Text + "," +

             lblNetPay.Text;

            System.IO.File.AppendAllText("Records.txt", s_data + Environment.NewLine);

            VM_LoadAllRecords();

            ClearFormData();
        }

        // Put the save data from file to its original field
        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadTheData();
        }

        // Product Selection As per product name
        private void chkShoes_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShoes.Checked)
            {
                txtShoesQ.Enabled = true;
            }
            else
            {
                txtShoesQ.Enabled = false;
                txtShoesQ.Text = "";
            }

        }

        // Product Selection As per product name
        private void chkJackets_CheckedChanged(object sender, EventArgs e)
        {
            if (chkJackets.Checked)
            {
                txtJacketsQ.Enabled = true;
            }
            else
            {
                txtJacketsQ.Enabled = false;
                txtJacketsQ.Text = "";
            }

        }

        // Product Selection As per product name
        private void chkGloves_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGloves.Checked)
            {
                txtGlovesQ.Enabled = true;

            }
            else
            {
                txtGlovesQ.Enabled = false;
                txtGlovesQ.Text = "";
            }
        }

        // Product Selection As per product name
        private void chkBeanies_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBeanies.Checked)
            {
                txtBeaniesQ.Enabled = true;
            }
            else
            {
                txtBeaniesQ.Enabled = false;
                txtBeaniesQ.Text = "";
            }

        }

        // Form Closing 
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
          DialogResult  Dialog =  MessageBox.Show("Are You Sure You want to Exit Without Saving?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (Dialog == DialogResult.Yes)
            {
                Application.Exit();
                
            }
            if (Dialog == DialogResult.No)
            {
                return;
            }
        }

        // if Bank Transfer is selected all data in credit will be clear 
        private void btnBankTransfer_CheckedChanged(object sender, EventArgs e)
        {
            this.txtNameOnCard.Text = "";
            this.txtCardNumber.Text = "";
            this.comboBoxCardType.Text = "";
            this.comboBoxExpiryMonth.Text = "";
            this.comboBoxExpiryYear.Text = "";
        }

        // if cash is selected all data in credit will be clear
        private void btnCash_CheckedChanged(object sender, EventArgs e)
        {
            this.txtNameOnCard.Text = "";
            this.txtCardNumber.Text = "";
            this.comboBoxCardType.Text = "";
            this.comboBoxExpiryMonth.Text = "";
            this.comboBoxExpiryYear.Text = "";
        }

        // Delete The records from the file(Help By Iwan)
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show(" Are You Sure You Want to Delete the record ?" 
             , "Information ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.No)
            {
                return;
            }

            lstAllRecords.Items.RemoveAt(lstAllRecords.SelectedIndex);

            string[] as_data = new string[lstAllRecords.Items.Count];

            lstAllRecords.Items.CopyTo(as_data, 0);

            System.IO.File.WriteAllLines("Records.txt", as_data);

        }

        // Log out the login User
        private void btnLogOut_Click(object sender, EventArgs e)
        {
           DialogResult Dialog =  MessageBox.Show(" Are You Sure You Want to log out ? ", "Log Out", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if(Dialog == DialogResult.Yes)
            {
                new LoginForm().Show();
                this.Close();
            }
            else
            {
                return;
            }
        }

        // Retrieved You Tube https://www.youtube.com/watch?v=41HK9SHg3K0
        // If instruction is been selected then it would redirect to another form 
        private void instructionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (f3 == null)
            {
                f3 = new Form3();
                f3.Show();
            }
            else
            {
                f3.Activate();
            }
        }

        // Retrieve from You Tube https://www.youtube.com/watch?v=41HK9SHg3K0
        // if About option is selected then it redirect to Another form
        private void aboutToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            if (f4 == null)
            {
                f4 = new Form4();
                f4.Show();
            }
            else
            {
                f4.Activate();
            }

        }

        // Close the window
        private void closeToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        // Gives us a new fresh Form by earse all things
        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearFormData();
            
        }

               
        // Loads the data and user can recheck/Update their data
        private void btnUpdate_Click(object sender, EventArgs e)
        {

            MessageBox.Show("while Updating Data Take Care of Following Things !!!!" + "\n" + "\n" +
                " Make sure you press calcuate button again if you had made any extra changes in order" + "\n" + "\n" +
                " After updating Data PRESS Save Button again to save updated record in file"
            , "Information ", MessageBoxButtons.OK, MessageBoxIcon.Question);

            DialogResult dialog = MessageBox.Show(" Are You Sure You Want to Update Data", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dialog == DialogResult.No)
            {
                return;
            }
            LoadTheData();

        }

        // Allow to search data if details are not able to find
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string[] as_entireData = System.IO.File.ReadAllLines("Records.txt");
            
            for (int i=0; i< as_entireData.Length;i++)
            {
                if (as_entireData[i].Contains(txtSearch.Text))
                {
                    lstAllRecords.SetSelected(i, true);
                    return;
                }
            }
           
        }

        // Matter for Giving new form to user
        private void ClearFormData()
        {
            this.txtFirstName.Text = "";
            this.txtLastName.Text = "";
            this.txtStreetAddress.Text = "";
            this.txtCity.Text = "";
            this.txtCardNumber.Text = "";
            this.txtNameOnCard.Text = "";
            this.chkGloves.Checked = false;
            this.chkJackets.Checked = false;
            this.chkShoes.Checked = false;
            this.chkBeanies.Checked = false;
            this.txtShoesQ.Text = "";
            this.txtGlovesQ.Text = "";
            this.txtJacketsQ.Text = "";
            this.txtBeaniesQ.Text = "";
            this.ComboBoxCountry.Text = "";
            this.comboBoxCardType.Text = "";
            this.comboBoxExpiryMonth.Text = "";
            this.comboBoxExpiryYear.Text = "";
            this.btnCash.Checked = false;
            this.btnBankTransfer.Checked = false;
            this.btnCreditCard.Checked = false;
            this.chkDiscount.Checked = false;
            this.lblNetPay.Text = "";
            this.txtGSTAmount.Text = "";
            this.chkDiscount.Checked = false;
            this.chkGSTRate.Checked = false;
            this.txtDiscountAmount.Text = "";
            this.txtDiscountRate.Text = "";
        }

        // Generate a brief history of sales system 
        private void btnReceipt_Click(object sender, EventArgs e)
        {
            // Error Message For Fist Name  & Last Name : 

            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                MessageBox.Show("FIRST NAME in Customer Details is mandatory.", "Error ! ",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                MessageBox.Show("Last Name in Customer Details is mandatory.", "Error ! ",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            // if payment option is not selected eroor message pop up
            if (btnCash.Checked == false && btnCreditCard.Checked == false && btnBankTransfer.Checked == false)
            {
                MessageBox.Show("Please Select Payment Option", "Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            // help by IWAN
            // message for credit card details if they are empty
            if ((btnCreditCard.Checked) && (String.IsNullOrEmpty(txtCardNumber.Text) || String.IsNullOrEmpty(txtCardNumber.Text) ||
                String.IsNullOrEmpty(comboBoxCardType.Text) || String.IsNullOrEmpty(comboBoxExpiryMonth.Text) || String.IsNullOrEmpty(comboBoxExpiryYear.Text)))
            {
                MessageBox.Show(" Kindly Put All Details in Credit Card Information to make Payment ", "ERROR!", MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            // if total is less than 50 if credit card is selected as payment Error message
            if (iTotal <= 50 && btnCreditCard.Checked)
            {
                MessageBox.Show(" Please Select Cash option Your Total Payable is below $50 So we Cant Go for Credit Card Payment Mode", "ERROR!", MessageBoxButtons.OK,MessageBoxIcon.Error);

                btnCreditCard.Checked = false;
                txtNameOnCard.Text = "";
                txtCardNumber.Text = "";
                comboBoxCardType.Text = "";
                comboBoxExpiryMonth.Text = "";
                comboBoxExpiryYear.Text = "";
                return;
            }

            // if total is more than 1200 if cash option is selected error message
            if (iTotal >= 1200 && btnCash.Checked)
            {
                MessageBox.Show("Please Select Credit Card option Your Total Payable is more than $1200 So we cant Process with Cash Payment Mode", "ERROR !", MessageBoxButtons.RetryCancel);
                btnCash.Checked = false;
                return;
            }

            // Message of Summary of Product + Quantity + Details Of Customer
            string s_Message;

            s_Message = "Customer Details:- " + "\n" + "\n" + "First Name:  " + txtFirstName.Text + "\n" +
                "Last Name:  " + txtLastName.Text + "\n" + "StreetAddress:  " + txtStreetAddress.Text +
                "\n" + "City:  " + txtCity.Text + "\n" + "Country:  " + ComboBoxCountry.Text;

            // Credit card details message if it is checked 
            if (btnCreditCard.Checked)
            {
                s_Message += "\n" + "\n" + "Credit Card Details" + "\n" + "\n" + "Name on Card : " + txtNameOnCard.Text + "\n" +
                    "Card Number : " + txtCardNumber.Text + "\n" + "Card Type : " + comboBoxCardType.Text + "\n"
                    + "Expiry: " + comboBoxExpiryMonth.Text + comboBoxExpiryYear.Text;
            }

            // Quantity Summary
            s_Message += "\n" + "\n" + "Purchase Item:- " + "\n" + "\n" + "Shoes: $25 X " + txtShoesQ.Text +
                "\n" + "Jackets: $20X" + txtJacketsQ.Text + "\n" + "Gloves: $15 X" + txtGlovesQ.Text +
                "\n" + "Beanies: $15 X " + txtBeaniesQ.Text + "\n" + "\n" +
                "Total Discount Applied $ : " + txtDiscountAmount.Text + "\n" +
                "Total GST Applied $: " + txtGSTAmount.Text +
                "\n" + "\n" + " Total Payable  $  :  " + lblNetPay.Text + "\n";
            MessageBox.Show(s_Message, "Summary");
        }

        // Only Numbers In Quantity of product textbox + Card Numnber text box NO alphabet allowed
        //Refrence (https://www.youtube.com/watch?v=UI2jhmLLMHU) YOU TUBE 
        private void NumbersOnly(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if(!char.IsDigit(ch) && ch !=8)
            {
                e.Handled = true;
            }
        }
    }
}
       