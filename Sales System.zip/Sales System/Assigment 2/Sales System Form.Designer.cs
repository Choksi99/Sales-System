﻿namespace Assigment_1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.bxCustomerDetails = new System.Windows.Forms.GroupBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtStreetAddress = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.ComboBoxCountry = new System.Windows.Forms.ComboBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblStreetAddress = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblfirstName = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBoxCardType = new System.Windows.Forms.ComboBox();
            this.comboBoxExpiryYear = new System.Windows.Forms.ComboBox();
            this.comboBoxExpiryMonth = new System.Windows.Forms.ComboBox();
            this.lblExpiry = new System.Windows.Forms.Label();
            this.txtCardNumber = new System.Windows.Forms.TextBox();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.lblCardType = new System.Windows.Forms.Label();
            this.txtNameOnCard = new System.Windows.Forms.TextBox();
            this.lblNameOnCard = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnBankTransfer = new System.Windows.Forms.RadioButton();
            this.btnCreditCard = new System.Windows.Forms.RadioButton();
            this.btnCash = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtBeaniesQ = new System.Windows.Forms.TextBox();
            this.chkGloves = new System.Windows.Forms.CheckBox();
            this.txtGlovesQ = new System.Windows.Forms.TextBox();
            this.txtJacketsQ = new System.Windows.Forms.TextBox();
            this.txtBeaniesRate = new System.Windows.Forms.TextBox();
            this.txtGlovesRate = new System.Windows.Forms.TextBox();
            this.chkBeanies = new System.Windows.Forms.CheckBox();
            this.txtJacketsRate = new System.Windows.Forms.TextBox();
            this.chkJackets = new System.Windows.Forms.CheckBox();
            this.txtShoesRate = new System.Windows.Forms.TextBox();
            this.chkShoes = new System.Windows.Forms.CheckBox();
            this.txtShoesQ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtGSTAmount = new System.Windows.Forms.TextBox();
            this.chkGSTRate = new System.Windows.Forms.CheckBox();
            this.txtDiscountAmount = new System.Windows.Forms.TextBox();
            this.txtDiscountRate = new System.Windows.Forms.TextBox();
            this.chkDiscount = new System.Windows.Forms.CheckBox();
            this.btnShowSummary = new System.Windows.Forms.Button();
            this.lblFinalAmount = new System.Windows.Forms.Label();
            this.lblNetPay = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.lstAllRecords = new System.Windows.Forms.ListBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnReceipt = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.moreOptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bxCustomerDetails.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bxCustomerDetails
            // 
            this.bxCustomerDetails.Controls.Add(this.txtLastName);
            this.bxCustomerDetails.Controls.Add(this.lblLastName);
            this.bxCustomerDetails.Controls.Add(this.txtStreetAddress);
            this.bxCustomerDetails.Controls.Add(this.txtCity);
            this.bxCustomerDetails.Controls.Add(this.ComboBoxCountry);
            this.bxCustomerDetails.Controls.Add(this.lblCountry);
            this.bxCustomerDetails.Controls.Add(this.lblCity);
            this.bxCustomerDetails.Controls.Add(this.lblStreetAddress);
            this.bxCustomerDetails.Controls.Add(this.txtFirstName);
            this.bxCustomerDetails.Controls.Add(this.lblfirstName);
            this.bxCustomerDetails.Location = new System.Drawing.Point(18, 37);
            this.bxCustomerDetails.Name = "bxCustomerDetails";
            this.bxCustomerDetails.Size = new System.Drawing.Size(374, 154);
            this.bxCustomerDetails.TabIndex = 0;
            this.bxCustomerDetails.TabStop = false;
            this.bxCustomerDetails.Text = "Customer Details";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(79, 42);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(257, 20);
            this.txtLastName.TabIndex = 3;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(3, 45);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(58, 13);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name";
            // 
            // txtStreetAddress
            // 
            this.txtStreetAddress.Location = new System.Drawing.Point(78, 68);
            this.txtStreetAddress.Name = "txtStreetAddress";
            this.txtStreetAddress.Size = new System.Drawing.Size(257, 20);
            this.txtStreetAddress.TabIndex = 5;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(78, 91);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(258, 20);
            this.txtCity.TabIndex = 7;
            // 
            // ComboBoxCountry
            // 
            this.ComboBoxCountry.Items.AddRange(new object[] {
            "India",
            "New Zealand",
            "Australia",
            "Canada",
            "USA",
            "UK"});
            this.ComboBoxCountry.Location = new System.Drawing.Point(78, 120);
            this.ComboBoxCountry.Name = "ComboBoxCountry";
            this.ComboBoxCountry.Size = new System.Drawing.Size(184, 21);
            this.ComboBoxCountry.TabIndex = 9;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(6, 120);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(43, 13);
            this.lblCountry.TabIndex = 8;
            this.lblCountry.Text = "Country";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(6, 90);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(24, 13);
            this.lblCity.TabIndex = 6;
            this.lblCity.Text = "City";
            // 
            // lblStreetAddress
            // 
            this.lblStreetAddress.AutoSize = true;
            this.lblStreetAddress.Location = new System.Drawing.Point(0, 71);
            this.lblStreetAddress.Name = "lblStreetAddress";
            this.lblStreetAddress.Size = new System.Drawing.Size(76, 13);
            this.lblStreetAddress.TabIndex = 4;
            this.lblStreetAddress.Text = "Street Address";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(78, 16);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(258, 20);
            this.txtFirstName.TabIndex = 1;
            // 
            // lblfirstName
            // 
            this.lblfirstName.AutoSize = true;
            this.lblfirstName.Location = new System.Drawing.Point(3, 16);
            this.lblfirstName.Name = "lblfirstName";
            this.lblfirstName.Size = new System.Drawing.Size(57, 13);
            this.lblfirstName.TabIndex = 0;
            this.lblfirstName.Text = "First Name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.comboBoxCardType);
            this.groupBox2.Controls.Add(this.comboBoxExpiryYear);
            this.groupBox2.Controls.Add(this.comboBoxExpiryMonth);
            this.groupBox2.Controls.Add(this.lblExpiry);
            this.groupBox2.Controls.Add(this.txtCardNumber);
            this.groupBox2.Controls.Add(this.lblCardNumber);
            this.groupBox2.Controls.Add(this.lblCardType);
            this.groupBox2.Controls.Add(this.txtNameOnCard);
            this.groupBox2.Controls.Add(this.lblNameOnCard);
            this.groupBox2.Location = new System.Drawing.Point(18, 197);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(368, 125);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Credit Card Information";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-6, -7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(380, 139);
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // comboBoxCardType
            // 
            this.comboBoxCardType.FormattingEnabled = true;
            this.comboBoxCardType.Items.AddRange(new object[] {
            "",
            "Visa",
            "Master Card",
            "American Express",
            "Diners Club",
            "Q Card"});
            this.comboBoxCardType.Location = new System.Drawing.Point(89, 42);
            this.comboBoxCardType.Name = "comboBoxCardType";
            this.comboBoxCardType.Size = new System.Drawing.Size(167, 21);
            this.comboBoxCardType.TabIndex = 3;
            // 
            // comboBoxExpiryYear
            // 
            this.comboBoxExpiryYear.FormattingEnabled = true;
            this.comboBoxExpiryYear.Location = new System.Drawing.Point(179, 94);
            this.comboBoxExpiryYear.Name = "comboBoxExpiryYear";
            this.comboBoxExpiryYear.Size = new System.Drawing.Size(77, 21);
            this.comboBoxExpiryYear.TabIndex = 8;
            // 
            // comboBoxExpiryMonth
            // 
            this.comboBoxExpiryMonth.FormattingEnabled = true;
            this.comboBoxExpiryMonth.Items.AddRange(new object[] {
            "",
            "January",
            "Febuary",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.comboBoxExpiryMonth.Location = new System.Drawing.Point(89, 94);
            this.comboBoxExpiryMonth.Name = "comboBoxExpiryMonth";
            this.comboBoxExpiryMonth.Size = new System.Drawing.Size(84, 21);
            this.comboBoxExpiryMonth.TabIndex = 7;
            // 
            // lblExpiry
            // 
            this.lblExpiry.AutoSize = true;
            this.lblExpiry.Location = new System.Drawing.Point(3, 98);
            this.lblExpiry.Name = "lblExpiry";
            this.lblExpiry.Size = new System.Drawing.Size(35, 13);
            this.lblExpiry.TabIndex = 6;
            this.lblExpiry.Text = "Expiry";
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.Location = new System.Drawing.Point(89, 68);
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Size = new System.Drawing.Size(240, 20);
            this.txtCardNumber.TabIndex = 5;
            this.txtCardNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbersOnly);
            // 
            // lblCardNumber
            // 
            this.lblCardNumber.AutoSize = true;
            this.lblCardNumber.Location = new System.Drawing.Point(6, 67);
            this.lblCardNumber.Name = "lblCardNumber";
            this.lblCardNumber.Size = new System.Drawing.Size(69, 13);
            this.lblCardNumber.TabIndex = 4;
            this.lblCardNumber.Text = "Card Number";
            // 
            // lblCardType
            // 
            this.lblCardType.AutoSize = true;
            this.lblCardType.Location = new System.Drawing.Point(6, 41);
            this.lblCardType.Name = "lblCardType";
            this.lblCardType.Size = new System.Drawing.Size(56, 13);
            this.lblCardType.TabIndex = 2;
            this.lblCardType.Text = "Card Type";
            // 
            // txtNameOnCard
            // 
            this.txtNameOnCard.Location = new System.Drawing.Point(89, 16);
            this.txtNameOnCard.Name = "txtNameOnCard";
            this.txtNameOnCard.Size = new System.Drawing.Size(240, 20);
            this.txtNameOnCard.TabIndex = 1;
            // 
            // lblNameOnCard
            // 
            this.lblNameOnCard.AutoSize = true;
            this.lblNameOnCard.Location = new System.Drawing.Point(6, 22);
            this.lblNameOnCard.Name = "lblNameOnCard";
            this.lblNameOnCard.Size = new System.Drawing.Size(77, 13);
            this.lblNameOnCard.TabIndex = 0;
            this.lblNameOnCard.Text = "Name On Card";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnBankTransfer);
            this.groupBox3.Controls.Add(this.btnCreditCard);
            this.groupBox3.Controls.Add(this.btnCash);
            this.groupBox3.Location = new System.Drawing.Point(21, 335);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(359, 53);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Payment Type";
            // 
            // btnBankTransfer
            // 
            this.btnBankTransfer.AutoSize = true;
            this.btnBankTransfer.Location = new System.Drawing.Point(175, 19);
            this.btnBankTransfer.Name = "btnBankTransfer";
            this.btnBankTransfer.Size = new System.Drawing.Size(92, 17);
            this.btnBankTransfer.TabIndex = 1;
            this.btnBankTransfer.TabStop = true;
            this.btnBankTransfer.Text = "Bank Transfer";
            this.btnBankTransfer.UseVisualStyleBackColor = true;
            this.btnBankTransfer.CheckedChanged += new System.EventHandler(this.btnBankTransfer_CheckedChanged);
            // 
            // btnCreditCard
            // 
            this.btnCreditCard.AutoSize = true;
            this.btnCreditCard.Location = new System.Drawing.Point(80, 19);
            this.btnCreditCard.Name = "btnCreditCard";
            this.btnCreditCard.Size = new System.Drawing.Size(77, 17);
            this.btnCreditCard.TabIndex = 1;
            this.btnCreditCard.TabStop = true;
            this.btnCreditCard.Text = "Credit Card";
            this.btnCreditCard.UseVisualStyleBackColor = true;
            this.btnCreditCard.CheckedChanged += new System.EventHandler(this.btnCreditCard_CheckedChanged);
            // 
            // btnCash
            // 
            this.btnCash.AutoSize = true;
            this.btnCash.Location = new System.Drawing.Point(6, 19);
            this.btnCash.Name = "btnCash";
            this.btnCash.Size = new System.Drawing.Size(49, 17);
            this.btnCash.TabIndex = 0;
            this.btnCash.TabStop = true;
            this.btnCash.Text = "Cash";
            this.btnCash.UseVisualStyleBackColor = true;
            this.btnCash.CheckedChanged += new System.EventHandler(this.btnCash_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtBeaniesQ);
            this.groupBox4.Controls.Add(this.chkGloves);
            this.groupBox4.Controls.Add(this.txtGlovesQ);
            this.groupBox4.Controls.Add(this.txtJacketsQ);
            this.groupBox4.Controls.Add(this.txtBeaniesRate);
            this.groupBox4.Controls.Add(this.txtGlovesRate);
            this.groupBox4.Controls.Add(this.chkBeanies);
            this.groupBox4.Controls.Add(this.txtJacketsRate);
            this.groupBox4.Controls.Add(this.chkJackets);
            this.groupBox4.Controls.Add(this.txtShoesRate);
            this.groupBox4.Controls.Add(this.chkShoes);
            this.groupBox4.Controls.Add(this.txtShoesQ);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Location = new System.Drawing.Point(407, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(265, 154);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Product Selection";
            // 
            // txtBeaniesQ
            // 
            this.txtBeaniesQ.Location = new System.Drawing.Point(190, 110);
            this.txtBeaniesQ.Name = "txtBeaniesQ";
            this.txtBeaniesQ.Size = new System.Drawing.Size(54, 20);
            this.txtBeaniesQ.TabIndex = 14;
            this.txtBeaniesQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbersOnly);
            // 
            // chkGloves
            // 
            this.chkGloves.AutoSize = true;
            this.chkGloves.Location = new System.Drawing.Point(18, 86);
            this.chkGloves.Name = "chkGloves";
            this.chkGloves.Size = new System.Drawing.Size(59, 17);
            this.chkGloves.TabIndex = 10;
            this.chkGloves.Text = "Gloves";
            this.chkGloves.UseVisualStyleBackColor = true;
            this.chkGloves.CheckedChanged += new System.EventHandler(this.chkGloves_CheckedChanged);
            // 
            // txtGlovesQ
            // 
            this.txtGlovesQ.Location = new System.Drawing.Point(190, 84);
            this.txtGlovesQ.Name = "txtGlovesQ";
            this.txtGlovesQ.Size = new System.Drawing.Size(54, 20);
            this.txtGlovesQ.TabIndex = 12;
            this.txtGlovesQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbersOnly);
            // 
            // txtJacketsQ
            // 
            this.txtJacketsQ.Location = new System.Drawing.Point(190, 59);
            this.txtJacketsQ.Name = "txtJacketsQ";
            this.txtJacketsQ.Size = new System.Drawing.Size(54, 20);
            this.txtJacketsQ.TabIndex = 9;
            this.txtJacketsQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbersOnly);
            // 
            // txtBeaniesRate
            // 
            this.txtBeaniesRate.Location = new System.Drawing.Point(120, 112);
            this.txtBeaniesRate.Name = "txtBeaniesRate";
            this.txtBeaniesRate.ReadOnly = true;
            this.txtBeaniesRate.Size = new System.Drawing.Size(57, 20);
            this.txtBeaniesRate.TabIndex = 14;
            // 
            // txtGlovesRate
            // 
            this.txtGlovesRate.Location = new System.Drawing.Point(120, 86);
            this.txtGlovesRate.Name = "txtGlovesRate";
            this.txtGlovesRate.ReadOnly = true;
            this.txtGlovesRate.Size = new System.Drawing.Size(57, 20);
            this.txtGlovesRate.TabIndex = 11;
            // 
            // chkBeanies
            // 
            this.chkBeanies.AutoSize = true;
            this.chkBeanies.Location = new System.Drawing.Point(18, 112);
            this.chkBeanies.Name = "chkBeanies";
            this.chkBeanies.Size = new System.Drawing.Size(64, 17);
            this.chkBeanies.TabIndex = 13;
            this.chkBeanies.Text = "Beanies";
            this.chkBeanies.UseVisualStyleBackColor = true;
            this.chkBeanies.CheckedChanged += new System.EventHandler(this.chkBeanies_CheckedChanged);
            // 
            // txtJacketsRate
            // 
            this.txtJacketsRate.Location = new System.Drawing.Point(120, 60);
            this.txtJacketsRate.Name = "txtJacketsRate";
            this.txtJacketsRate.ReadOnly = true;
            this.txtJacketsRate.Size = new System.Drawing.Size(57, 20);
            this.txtJacketsRate.TabIndex = 8;
            // 
            // chkJackets
            // 
            this.chkJackets.AutoSize = true;
            this.chkJackets.Location = new System.Drawing.Point(18, 62);
            this.chkJackets.Name = "chkJackets";
            this.chkJackets.Size = new System.Drawing.Size(63, 17);
            this.chkJackets.TabIndex = 7;
            this.chkJackets.Text = "Jackets";
            this.chkJackets.UseVisualStyleBackColor = true;
            this.chkJackets.CheckedChanged += new System.EventHandler(this.chkJackets_CheckedChanged);
            // 
            // txtShoesRate
            // 
            this.txtShoesRate.Location = new System.Drawing.Point(120, 35);
            this.txtShoesRate.Name = "txtShoesRate";
            this.txtShoesRate.ReadOnly = true;
            this.txtShoesRate.Size = new System.Drawing.Size(57, 20);
            this.txtShoesRate.TabIndex = 5;
            // 
            // chkShoes
            // 
            this.chkShoes.AutoSize = true;
            this.chkShoes.Location = new System.Drawing.Point(18, 37);
            this.chkShoes.Name = "chkShoes";
            this.chkShoes.Size = new System.Drawing.Size(56, 17);
            this.chkShoes.TabIndex = 4;
            this.chkShoes.Text = "Shoes";
            this.chkShoes.UseVisualStyleBackColor = true;
            this.chkShoes.CheckedChanged += new System.EventHandler(this.chkShoes_CheckedChanged);
            // 
            // txtShoesQ
            // 
            this.txtShoesQ.Location = new System.Drawing.Point(190, 35);
            this.txtShoesQ.Name = "txtShoesQ";
            this.txtShoesQ.Size = new System.Drawing.Size(54, 20);
            this.txtShoesQ.TabIndex = 6;
            this.txtShoesQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NumbersOnly);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(198, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(124, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Unit Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Product Details";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtGSTAmount);
            this.groupBox5.Controls.Add(this.chkGSTRate);
            this.groupBox5.Controls.Add(this.txtDiscountAmount);
            this.groupBox5.Controls.Add(this.txtDiscountRate);
            this.groupBox5.Controls.Add(this.chkDiscount);
            this.groupBox5.Location = new System.Drawing.Point(407, 177);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(265, 74);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Other Fees";
            // 
            // txtGSTAmount
            // 
            this.txtGSTAmount.Enabled = false;
            this.txtGSTAmount.Location = new System.Drawing.Point(184, 43);
            this.txtGSTAmount.Name = "txtGSTAmount";
            this.txtGSTAmount.ReadOnly = true;
            this.txtGSTAmount.Size = new System.Drawing.Size(71, 20);
            this.txtGSTAmount.TabIndex = 4;
            // 
            // chkGSTRate
            // 
            this.chkGSTRate.AutoSize = true;
            this.chkGSTRate.Location = new System.Drawing.Point(19, 46);
            this.chkGSTRate.Name = "chkGSTRate";
            this.chkGSTRate.Size = new System.Drawing.Size(74, 17);
            this.chkGSTRate.TabIndex = 3;
            this.chkGSTRate.Text = "GST(15%)";
            this.chkGSTRate.UseVisualStyleBackColor = true;
            // 
            // txtDiscountAmount
            // 
            this.txtDiscountAmount.Enabled = false;
            this.txtDiscountAmount.Location = new System.Drawing.Point(184, 22);
            this.txtDiscountAmount.Name = "txtDiscountAmount";
            this.txtDiscountAmount.ReadOnly = true;
            this.txtDiscountAmount.Size = new System.Drawing.Size(71, 20);
            this.txtDiscountAmount.TabIndex = 2;
            // 
            // txtDiscountRate
            // 
            this.txtDiscountRate.Location = new System.Drawing.Point(110, 22);
            this.txtDiscountRate.Name = "txtDiscountRate";
            this.txtDiscountRate.Size = new System.Drawing.Size(54, 20);
            this.txtDiscountRate.TabIndex = 1;
            // 
            // chkDiscount
            // 
            this.chkDiscount.AutoSize = true;
            this.chkDiscount.Location = new System.Drawing.Point(19, 24);
            this.chkDiscount.Name = "chkDiscount";
            this.chkDiscount.Size = new System.Drawing.Size(85, 17);
            this.chkDiscount.TabIndex = 0;
            this.chkDiscount.Text = "Discount (%)";
            this.chkDiscount.UseVisualStyleBackColor = true;
            // 
            // btnShowSummary
            // 
            this.btnShowSummary.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnShowSummary.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowSummary.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnShowSummary.Location = new System.Drawing.Point(465, 308);
            this.btnShowSummary.Name = "btnShowSummary";
            this.btnShowSummary.Size = new System.Drawing.Size(119, 34);
            this.btnShowSummary.TabIndex = 5;
            this.btnShowSummary.Text = "Calculate";
            this.btnShowSummary.UseVisualStyleBackColor = false;
            this.btnShowSummary.Click += new System.EventHandler(this.btnShowSummary_Click);
            // 
            // lblFinalAmount
            // 
            this.lblFinalAmount.AutoSize = true;
            this.lblFinalAmount.Location = new System.Drawing.Point(413, 272);
            this.lblFinalAmount.Name = "lblFinalAmount";
            this.lblFinalAmount.Size = new System.Drawing.Size(83, 13);
            this.lblFinalAmount.TabIndex = 10;
            this.lblFinalAmount.Text = "Final Amount : $";
            // 
            // lblNetPay
            // 
            this.lblNetPay.AutoSize = true;
            this.lblNetPay.Location = new System.Drawing.Point(511, 272);
            this.lblNetPay.Name = "lblNetPay";
            this.lblNetPay.Size = new System.Drawing.Size(0, 13);
            this.lblNetPay.TabIndex = 7;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(392, 378);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(89, 23);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(496, 378);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(95, 23);
            this.btnLoad.TabIndex = 16;
            this.btnLoad.Text = "Check Details";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // lstAllRecords
            // 
            this.lstAllRecords.FormattingEnabled = true;
            this.lstAllRecords.Location = new System.Drawing.Point(703, 7);
            this.lstAllRecords.Name = "lstAllRecords";
            this.lstAllRecords.Size = new System.Drawing.Size(299, 394);
            this.lstAllRecords.TabIndex = 17;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(597, 375);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(392, 348);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(89, 23);
            this.btnNew.TabIndex = 20;
            this.btnNew.Text = "Void Sale";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnReceipt
            // 
            this.btnReceipt.Location = new System.Drawing.Point(509, 349);
            this.btnReceipt.Name = "btnReceipt";
            this.btnReceipt.Size = new System.Drawing.Size(75, 23);
            this.btnReceipt.TabIndex = 21;
            this.btnReceipt.Text = "Receipt";
            this.btnReceipt.UseVisualStyleBackColor = true;
            this.btnReceipt.Click += new System.EventHandler(this.btnReceipt_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(597, 348);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(75, 23);
            this.btnLogOut.TabIndex = 22;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.moreOptionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1014, 24);
            this.menuStrip1.TabIndex = 23;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // moreOptionToolStripMenuItem
            // 
            this.moreOptionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.aboutToolStripMenuItem1,
            this.closeToolStripMenuItem});
            this.moreOptionToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("moreOptionToolStripMenuItem.Image")));
            this.moreOptionToolStripMenuItem.Name = "moreOptionToolStripMenuItem";
            this.moreOptionToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.moreOptionToolStripMenuItem.Text = "More Option";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.instructionToolStripMenuItem});
            this.aboutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aboutToolStripMenuItem.Image")));
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // instructionToolStripMenuItem
            // 
            this.instructionToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("instructionToolStripMenuItem.Image")));
            this.instructionToolStripMenuItem.Name = "instructionToolStripMenuItem";
            this.instructionToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.instructionToolStripMenuItem.Text = "Instruction";
            this.instructionToolStripMenuItem.Click += new System.EventHandler(this.instructionToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("aboutToolStripMenuItem1.Image")));
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click_1);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("closeToolStripMenuItem.Image")));
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click_1);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(396, 407);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(100, 20);
            this.txtSearch.TabIndex = 0;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(514, 404);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 25;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(597, 404);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 26;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 22);
            this.label1.TabIndex = 27;
            this.label1.Text = "Vrajesh Choksi Developer ©  Version 1.2.1.0";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1014, 431);
            this.Controls.Add(this.lstAllRecords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnReceipt);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblNetPay);
            this.Controls.Add(this.lblFinalAmount);
            this.Controls.Add(this.btnShowSummary);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.bxCustomerDetails);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "Sales System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.bxCustomerDetails.ResumeLayout(false);
            this.bxCustomerDetails.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox bxCustomerDetails;
        private System.Windows.Forms.Label lblStreetAddress;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblExpiry;
        private System.Windows.Forms.TextBox txtCardNumber;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.Label lblCardType;
        private System.Windows.Forms.TextBox txtNameOnCard;
        private System.Windows.Forms.Label lblNameOnCard;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkShoes;
        private System.Windows.Forms.TextBox txtShoesQ;
        private System.Windows.Forms.TextBox txtShoesRate;
        private System.Windows.Forms.CheckBox chkJackets;
        private System.Windows.Forms.TextBox txtBeaniesRate;
        private System.Windows.Forms.TextBox txtGlovesRate;
        private System.Windows.Forms.CheckBox chkBeanies;
        private System.Windows.Forms.TextBox txtJacketsRate;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtDiscountAmount;
        private System.Windows.Forms.TextBox txtDiscountRate;
        private System.Windows.Forms.CheckBox chkDiscount;
        private System.Windows.Forms.Button btnShowSummary;
        private System.Windows.Forms.ComboBox ComboBoxCountry;
        private System.Windows.Forms.ComboBox comboBoxExpiryYear;
        private System.Windows.Forms.ComboBox comboBoxExpiryMonth;
        private System.Windows.Forms.RadioButton btnBankTransfer;
        private System.Windows.Forms.RadioButton btnCreditCard;
        private System.Windows.Forms.RadioButton btnCash;
        private System.Windows.Forms.ComboBox comboBoxCardType;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtStreetAddress;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtJacketsQ;
        private System.Windows.Forms.TextBox txtGlovesQ;
        private System.Windows.Forms.CheckBox chkGloves;
        private System.Windows.Forms.TextBox txtBeaniesQ;
        private System.Windows.Forms.Label lblFinalAmount;
        private System.Windows.Forms.Label lblfirstName;
        private System.Windows.Forms.Label lblNetPay;
        private System.Windows.Forms.CheckBox chkGSTRate;
        private System.Windows.Forms.TextBox txtGSTAmount;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.ListBox lstAllRecords;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnReceipt;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem moreOptionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instructionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

