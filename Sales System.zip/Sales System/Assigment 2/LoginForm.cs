﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Threading;


namespace Assigment_1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
           
        }

     // Login Button Commands
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Error message for inputting wrong user name 
            if (string.IsNullOrWhiteSpace(txtUserName.Text))
            {
                MessageBox.Show("Please Input a valid User Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Error message for inputting wrong password
            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Please Input a valid Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

           // Error message for selecting wrong type of login
            if (string.IsNullOrWhiteSpace(cmbType.Text))
            {
                MessageBox.Show("Please select TYPE option", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // password criteria
            if ((txtUserName.Text == "vrajesh") && (txtPassword.Text == "choksi") && (cmbType.Text == "Client"))
            {
                MessageBox.Show("You are successfully Logged in !", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
    
                    new Form2().Show();
            }
            else
            {
                // Login Fail 
                MessageBox.Show(" Login Failed! Please Try Again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.txtUserName.Text = "";
                this.txtPassword.Text = "";
                this.cmbType.Text = "";
            }
        }

        // Exit the Application
        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are You Sure You want to Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }

        }
    }

}